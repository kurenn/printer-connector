package cloud

type RegisterRequest struct {
	PairingToken string     `json:"pairing_token"`
	SiteName     string     `json:"site_name,omitempty"`
	Device       DeviceInfo `json:"device"`
}

type DeviceInfo struct {
	Hostname string `json:"hostname,omitempty"`
	Arch     string `json:"arch,omitempty"`
	OS       string `json:"os,omitempty"`
	Version  string `json:"version,omitempty"`
}

type RegisterResponse struct {
	Connector struct {
		ID string `json:"id"`
	} `json:"connector"`
	Credentials struct {
		Secret string `json:"secret"`
	} `json:"credentials"`
	Polling struct {
		CommandsSeconds  int `json:"commands_seconds"`
		SnapshotsSeconds int `json:"snapshots_seconds"`
	} `json:"polling"`
}

type HeartbeatRequest struct {
	Status struct {
		UptimeSeconds int64  `json:"uptime_seconds"`
		Version       string `json:"version,omitempty"`
	} `json:"status"`
	Printers []HeartbeatPrinter `json:"printers,omitempty"`
}

type HeartbeatPrinter struct {
	PrinterID int  `json:"printer_id"`
	Reachable bool `json:"reachable"`
}

type Command struct {
	ID        string         `json:"id"`
	PrinterID int            `json:"printer_id"`
	Action    string         `json:"action"`
	Params    map[string]any `json:"params"`
}

type CommandCompleteRequest struct {
	Status       string         `json:"status"`
	Result       map[string]any `json:"result,omitempty"`
	ErrorMessage string         `json:"error_message,omitempty"`
}

type SnapshotsBatchRequest struct {
	Snapshots []Snapshot `json:"snapshots"`
}

type Snapshot struct {
	PrinterID  int            `json:"printer_id"`
	CapturedAt string         `json:"captured_at"`
	Payload    map[string]any `json:"payload"`
}

type SnapshotsBatchResponse struct {
	Inserted int `json:"inserted"`
}
